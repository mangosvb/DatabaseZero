/*
SQLyog Community v8.5 
MySQL - 5.1.45-community : Database - spuriouszero
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`spuriouszero` /*!40100 DEFAULT CHARACTER SET latin1 */;

/*Table structure for table `realms` */

DROP TABLE IF EXISTS `realms`;

CREATE TABLE `realms` (
  `ws_name` varchar(50) NOT NULL DEFAULT '',
  `ws_host` varchar(50) NOT NULL DEFAULT '',
  `ws_port` int(5) NOT NULL DEFAULT '0',
  `ws_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ws_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ws_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ws_population` float(3,0) unsigned NOT NULL DEFAULT '0',
  `ws_timezone` tinyint(3) NOT NULL DEFAULT '1',
  `gmonly` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ws_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `realms` */

insert  into `realms`(`ws_name`,`ws_host`,`ws_port`,`ws_status`,`ws_id`,`ws_type`,`ws_population`,`ws_timezone`,`gmonly`) values ('SpuriousZero Test Server','5.61.20.100',8085,0,0,0,0,1,0);
insert  into `realms`(`ws_name`,`ws_host`,`ws_port`,`ws_status`,`ws_id`,`ws_type`,`ws_population`,`ws_timezone`,`gmonly`) values ('SpuriousZero Lan Server','192.168.1.65',8085,0,1,0,0,1,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
