/*
SQLyog Community v8.5 
MySQL - 5.1.45-community : Database - spuriouszeroaccount
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`spuriouszeroaccount` /*!40100 DEFAULT CHARACTER SET latin1 */;

/*Table structure for table `account_data` */

DROP TABLE IF EXISTS `account_data`;

CREATE TABLE `account_data` (
  `account_id` int(4) NOT NULL,
  `account_data0` blob NOT NULL,
  `account_data1` blob NOT NULL,
  `account_data2` blob NOT NULL,
  `account_data3` blob NOT NULL,
  `account_data4` blob NOT NULL,
  `account_data5` blob NOT NULL,
  `account_data6` blob NOT NULL,
  `account_data7` blob NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `account_data` */

/*Table structure for table `accounts` */

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `account` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(40) NOT NULL DEFAULT '',
  `plevel` mediumint(3) unsigned NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL DEFAULT '',
  `joindate` varchar(10) NOT NULL DEFAULT '00-00-0000',
  `last_sshash` varchar(90) NOT NULL DEFAULT '',
  `last_ip` varchar(15) NOT NULL DEFAULT '',
  `last_login` varchar(100) NOT NULL DEFAULT '0000-00-00',
  `banned` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `account_id` int(4) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`account_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `accounts` */

/*Table structure for table `bans` */

DROP TABLE IF EXISTS `bans`;

CREATE TABLE `bans` (
  `ip` varchar(100) NOT NULL DEFAULT '',
  `date` date DEFAULT '0000-00-00',
  `reason` varchar(100) DEFAULT NULL,
  `who` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `bans` */

/*Table structure for table `realms` */

DROP TABLE IF EXISTS `realms`;

CREATE TABLE `realms` (
  `ws_name` varchar(50) NOT NULL DEFAULT '',
  `ws_host` varchar(50) NOT NULL DEFAULT '',
  `ws_port` int(5) NOT NULL DEFAULT '0',
  `ws_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ws_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ws_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ws_population` float(3,0) unsigned NOT NULL DEFAULT '0',
  `ws_timezone` tinyint(3) NOT NULL DEFAULT '1',
  `gmonly` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ws_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `realms` */

insert  into `realms`(`ws_name`,`ws_host`,`ws_port`,`ws_status`,`ws_id`,`ws_type`,`ws_population`,`ws_timezone`,`gmonly`) values ('SpuriousZero Lan Server','192.168.1.65',8085,0,0,0,0,1,0);
insert  into `realms`(`ws_name`,`ws_host`,`ws_port`,`ws_status`,`ws_id`,`ws_type`,`ws_population`,`ws_timezone`,`gmonly`) values ('SpuriousZero Test Server','5.61.20.100',8085,0,1,0,0,1,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
