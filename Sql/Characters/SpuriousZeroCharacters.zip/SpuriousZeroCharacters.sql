/*
SQLyog Community v8.5 
MySQL - 5.1.45-community : Database - spuriouszerocharacters
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`spuriouszerocharacters` /*!40100 DEFAULT CHARACTER SET latin1 */;

/*Table structure for table `auctionhouse` */

DROP TABLE IF EXISTS `auctionhouse`;

CREATE TABLE `auctionhouse` (
  `auction_id` int(11) NOT NULL AUTO_INCREMENT,
  `auction_bid` int(11) NOT NULL,
  `auction_buyout` int(11) NOT NULL,
  `auction_timeleft` int(11) NOT NULL,
  `auction_bidder` int(11) NOT NULL DEFAULT '0',
  `auction_owner` int(11) NOT NULL,
  `auction_itemId` mediumint(11) NOT NULL,
  `auction_itemCount` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `auction_itemGUID` int(11) NOT NULL,
  PRIMARY KEY (`auction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `auctionhouse` */

/*Table structure for table `characters` */

DROP TABLE IF EXISTS `characters`;

CREATE TABLE `characters` (
  `account_id` mediumint(3) unsigned NOT NULL DEFAULT '0',
  `char_guid` int(8) NOT NULL AUTO_INCREMENT,
  `char_name` varchar(21) NOT NULL DEFAULT '',
  `char_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_xp` mediumint(3) NOT NULL DEFAULT '0',
  `char_xp_rested` mediumint(3) NOT NULL DEFAULT '0',
  `char_online` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_logouttime` int(8) unsigned NOT NULL DEFAULT '0',
  `char_positionX` float NOT NULL DEFAULT '0',
  `char_positionY` float NOT NULL DEFAULT '0',
  `char_positionZ` float NOT NULL DEFAULT '0',
  `char_map_id` smallint(2) NOT NULL DEFAULT '0',
  `char_zone_id` smallint(2) NOT NULL DEFAULT '0',
  `char_orientation` float NOT NULL DEFAULT '0',
  `char_moviePlayed` tinyint(1) NOT NULL DEFAULT '0',
  `bindpoint_positionX` float NOT NULL DEFAULT '0',
  `bindpoint_positionY` float NOT NULL DEFAULT '0',
  `bindpoint_positionZ` float NOT NULL DEFAULT '0',
  `bindpoint_map_id` smallint(2) NOT NULL DEFAULT '0',
  `bindpoint_zone_id` smallint(2) NOT NULL DEFAULT '0',
  `char_guildId` int(1) NOT NULL DEFAULT '0',
  `char_guildRank` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_guildPNote` varchar(255) NOT NULL DEFAULT '',
  `char_guildOffNote` varchar(255) NOT NULL DEFAULT '',
  `char_race` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_class` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_gender` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_skin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_face` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_hairStyle` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_hairColor` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_facialHair` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_restState` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_mana` smallint(2) NOT NULL DEFAULT '1',
  `char_energy` smallint(2) NOT NULL DEFAULT '0',
  `char_rage` smallint(2) NOT NULL DEFAULT '0',
  `char_life` smallint(2) NOT NULL DEFAULT '1',
  `char_manaType` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_strength` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_agility` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_stamina` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_intellect` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_spirit` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_copper` int(6) unsigned NOT NULL DEFAULT '0',
  `char_watchedFactionIndex` tinyint(1) unsigned NOT NULL DEFAULT '255',
  `char_reputation` text NOT NULL,
  `char_skillList` text NOT NULL,
  `char_auraList` text NOT NULL,
  `char_tutorialFlags` varchar(255) NOT NULL DEFAULT '',
  `char_taxiFlags` varchar(255) NOT NULL DEFAULT '',
  `char_actionBar` text NOT NULL,
  `char_mapExplored` text NOT NULL,
  `force_restrictions` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_talentPoints` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_bankSlots` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `char_transportGuid` bigint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `characters` */

/*Table structure for table `characters_honor` */

DROP TABLE IF EXISTS `characters_honor`;

CREATE TABLE `characters_honor` (
  `char_guid` bigint(20) NOT NULL DEFAULT '0',
  `honor_points` smallint(6) NOT NULL DEFAULT '0',
  `honor_rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `honor_hightestRank` tinyint(3) NOT NULL DEFAULT '0',
  `standing_lastweek` smallint(11) NOT NULL DEFAULT '0',
  `kills_honor` mediumint(13) NOT NULL DEFAULT '0',
  `kills_dishonor` mediumint(13) NOT NULL DEFAULT '0',
  `honor_lastWeek` smallint(11) NOT NULL DEFAULT '0',
  `honor_thisWeek` smallint(11) NOT NULL DEFAULT '0',
  `honor_yesterday` smallint(11) NOT NULL DEFAULT '0',
  `kills_lastWeek` smallint(11) NOT NULL DEFAULT '0',
  `kills_thisWeek` smallint(11) NOT NULL DEFAULT '0',
  `kills_yesterday` smallint(11) NOT NULL DEFAULT '0',
  `kills_today` smallint(11) NOT NULL DEFAULT '0',
  `kills_dishonortoday` smallint(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `characters_honor` */

/*Table structure for table `characters_instances` */

DROP TABLE IF EXISTS `characters_instances`;

CREATE TABLE `characters_instances` (
  `char_guid` int(8) NOT NULL,
  `map` smallint(2) unsigned NOT NULL DEFAULT '0',
  `instance` int(8) unsigned NOT NULL DEFAULT '0',
  `expire` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_guid`,`map`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `characters_instances` */

/*Table structure for table `characters_instances_group` */

DROP TABLE IF EXISTS `characters_instances_group`;

CREATE TABLE `characters_instances_group` (
  `group_id` int(8) NOT NULL,
  `map` smallint(2) unsigned NOT NULL DEFAULT '0',
  `instance` int(8) unsigned NOT NULL DEFAULT '0',
  `expire` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`,`map`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `characters_instances_group` */

/*Table structure for table `characters_inventory` */

DROP TABLE IF EXISTS `characters_inventory`;

CREATE TABLE `characters_inventory` (
  `item_guid` bigint(8) NOT NULL DEFAULT '0',
  `item_id` smallint(2) unsigned NOT NULL DEFAULT '0',
  `item_slot` tinyint(6) unsigned NOT NULL DEFAULT '255',
  `item_bag` bigint(8) NOT NULL DEFAULT '-1',
  `item_owner` bigint(8) NOT NULL DEFAULT '0',
  `item_creator` bigint(8) NOT NULL DEFAULT '0',
  `item_giftCreator` bigint(8) NOT NULL DEFAULT '0',
  `item_stackCount` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `item_durability` smallint(2) NOT NULL DEFAULT '0',
  `item_flags` smallint(11) NOT NULL DEFAULT '0',
  `item_chargesLeft` tinyint(1) NOT NULL DEFAULT '0',
  `item_textId` smallint(6) NOT NULL DEFAULT '0',
  `item_enchantment` varchar(255) NOT NULL DEFAULT '',
  `item_random_properties` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `characters_inventory` */

/*Table structure for table `characters_mail` */

DROP TABLE IF EXISTS `characters_mail`;

CREATE TABLE `characters_mail` (
  `mail_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `mail_sender` bigint(20) NOT NULL DEFAULT '0',
  `mail_receiver` bigint(20) NOT NULL DEFAULT '0',
  `mail_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mail_stationary` smallint(4) NOT NULL DEFAULT '41',
  `mail_subject` varchar(255) NOT NULL DEFAULT '',
  `mail_body` varchar(255) NOT NULL DEFAULT '',
  `mail_money` int(6) NOT NULL DEFAULT '0',
  `mail_COD` smallint(6) NOT NULL DEFAULT '0',
  `mail_time` int(6) NOT NULL DEFAULT '30',
  `mail_read` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` bigint(20) NOT NULL,
  PRIMARY KEY (`mail_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `characters_mail` */

/*Table structure for table `characters_pets` */

DROP TABLE IF EXISTS `characters_pets`;

CREATE TABLE `characters_pets` (
  `pet_guid` int(8) NOT NULL,
  `pet_owner` int(8) NOT NULL,
  `pet_entry` int(8) NOT NULL DEFAULT '0',
  `pet_model` int(8) NOT NULL DEFAULT '0',
  `pet_family` tinyint(1) NOT NULL DEFAULT '0',
  `pet_name` varchar(50) NOT NULL DEFAULT 'Noname',
  `pet_level` tinyint(1) NOT NULL DEFAULT '0',
  `pet_xp` int(8) NOT NULL DEFAULT '0',
  `pet_renamed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pet_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `characters_pets` */

/*Table structure for table `characters_quests` */

DROP TABLE IF EXISTS `characters_quests`;

CREATE TABLE `characters_quests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `char_guid` bigint(20) NOT NULL DEFAULT '0',
  `quest_id` int(11) NOT NULL DEFAULT '0',
  `quest_status` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

/*Data for the table `characters_quests` */

/*Table structure for table `characters_social` */

DROP TABLE IF EXISTS `characters_social`;

CREATE TABLE `characters_social` (
  `char_guid` bigint(20) unsigned NOT NULL,
  `guid` bigint(20) unsigned NOT NULL,
  `note` varchar(255) NOT NULL,
  `flags` smallint(6) NOT NULL,
  PRIMARY KEY (`char_guid`,`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `characters_social` */

/*Table structure for table `characters_spells` */

DROP TABLE IF EXISTS `characters_spells`;

CREATE TABLE `characters_spells` (
  `guid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `spellid` int(8) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `cooldown` int(8) unsigned NOT NULL DEFAULT '0',
  `cooldownitem` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spellid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `characters_spells` */

/*Table structure for table `characters_tickets` */

DROP TABLE IF EXISTS `characters_tickets`;

CREATE TABLE `characters_tickets` (
  `char_guid` bigint(20) NOT NULL DEFAULT '0',
  `ticket_text` text NOT NULL,
  `ticket_x` float NOT NULL DEFAULT '0',
  `ticket_y` float NOT NULL DEFAULT '0',
  `ticket_z` float NOT NULL DEFAULT '0',
  `ticket_map` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `characters_tickets` */

/*Table structure for table `guilds` */

DROP TABLE IF EXISTS `guilds`;

CREATE TABLE `guilds` (
  `guild_id` int(11) NOT NULL AUTO_INCREMENT,
  `guild_name` varchar(255) NOT NULL,
  `guild_leader` int(11) NOT NULL DEFAULT '0',
  `guild_MOTD` varchar(255) NOT NULL DEFAULT '',
  `guild_info` varchar(255) NOT NULL DEFAULT '',
  `guild_cYear` int(6) unsigned NOT NULL DEFAULT '0',
  `guild_cMonth` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guild_cDay` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guild_tEmblemStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guild_tEmblemColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guild_tBorderStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guild_tBorderColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guild_tBackgroundColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guild_rank0` varchar(255) NOT NULL DEFAULT 'Guild Master',
  `guild_rank0_Rights` int(11) NOT NULL DEFAULT '61951',
  `guild_rank1` varchar(255) NOT NULL DEFAULT 'Officer',
  `guild_rank1_Rights` int(11) NOT NULL DEFAULT '67',
  `guild_rank2` varchar(255) NOT NULL DEFAULT 'Veteran',
  `guild_rank2_Rights` int(11) NOT NULL DEFAULT '67',
  `guild_rank3` varchar(255) NOT NULL DEFAULT 'Member',
  `guild_rank3_Rights` int(11) NOT NULL DEFAULT '67',
  `guild_rank4` varchar(255) NOT NULL DEFAULT 'Initiate',
  `guild_rank4_Rights` int(11) NOT NULL DEFAULT '67',
  `guild_rank5` varchar(255) NOT NULL DEFAULT '',
  `guild_rank5_Rights` int(11) NOT NULL DEFAULT '0',
  `guild_rank6` varchar(255) NOT NULL DEFAULT '',
  `guild_rank6_Rights` int(11) NOT NULL DEFAULT '0',
  `guild_rank7` varchar(255) NOT NULL DEFAULT '',
  `guild_rank7_Rights` int(11) NOT NULL DEFAULT '0',
  `guild_rank8` varchar(255) NOT NULL DEFAULT '',
  `guild_rank8_Rights` int(11) NOT NULL DEFAULT '0',
  `guild_rank9` varchar(255) NOT NULL DEFAULT '',
  `guild_rank9_Rights` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guild_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `guilds` */

/*Table structure for table `petitions` */

DROP TABLE IF EXISTS `petitions`;

CREATE TABLE `petitions` (
  `petition_id` int(11) NOT NULL,
  `petition_itemGuid` int(11) NOT NULL,
  `petition_owner` int(11) NOT NULL,
  `petition_name` varchar(255) NOT NULL,
  `petition_type` tinyint(3) unsigned NOT NULL,
  `petition_signedMembers` tinyint(3) unsigned NOT NULL,
  `petition_signedMember1` int(11) NOT NULL DEFAULT '0',
  `petition_signedMember2` int(11) NOT NULL DEFAULT '0',
  `petition_signedMember3` int(11) NOT NULL DEFAULT '0',
  `petition_signedMember4` int(11) NOT NULL DEFAULT '0',
  `petition_signedMember5` int(11) NOT NULL DEFAULT '0',
  `petition_signedMember6` int(11) NOT NULL DEFAULT '0',
  `petition_signedMember7` int(11) NOT NULL DEFAULT '0',
  `petition_signedMember8` int(11) NOT NULL DEFAULT '0',
  `petition_signedMember9` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`petition_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `petitions` */

/*Table structure for table `tmpspawnedcorpses` */

DROP TABLE IF EXISTS `tmpspawnedcorpses`;

CREATE TABLE `tmpspawnedcorpses` (
  `corpse_guid` bigint(20) NOT NULL DEFAULT '0',
  `corpse_owner` bigint(20) NOT NULL DEFAULT '0',
  `corpse_positionX` float NOT NULL DEFAULT '0',
  `corpse_positionY` float NOT NULL DEFAULT '0',
  `corpse_positionZ` float NOT NULL DEFAULT '0',
  `corpse_orientation` float NOT NULL DEFAULT '0',
  `corpse_mapId` int(10) unsigned NOT NULL DEFAULT '0',
  `corpse_bytes1` int(11) NOT NULL DEFAULT '0',
  `corpse_bytes2` int(11) NOT NULL DEFAULT '0',
  `corpse_model` int(10) unsigned NOT NULL DEFAULT '0',
  `corpse_guild` int(10) unsigned NOT NULL DEFAULT '0',
  `corpse_items` varchar(255) NOT NULL DEFAULT '',
  `corpse_instance` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`corpse_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `tmpspawnedcorpses` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
